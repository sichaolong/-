package henu.soft.xiaosi.pojo;

import lombok.*;

/**
 * 管理员实体类
 */

@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Admin extends User {

    private String password;
    private String role;


}
