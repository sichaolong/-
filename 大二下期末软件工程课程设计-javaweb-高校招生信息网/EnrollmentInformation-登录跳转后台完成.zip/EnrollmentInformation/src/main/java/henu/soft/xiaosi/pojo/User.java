package henu.soft.xiaosi.pojo;

import lombok.*;


/**
 * 用户实体父类，包括 管理员、一般游客属性（用于查询录取）
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class User {

    private String name;
    private String userNumber;


}
