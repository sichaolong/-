package henu.soft.xiaosi.pojo;

import lombok.*;

/**
 * 游客实体类，便于留言信息记录
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Visitor extends User {

    private int phone;
    private String email;
    private String examSubject;
    private double examScore;
    private String location;
    private String highSchool;
    private String problemClassification;
    private String problem;

}
