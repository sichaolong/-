package henu.soft.xiaosi.config;

import henu.soft.xiaosi.mapper.LoginMapper;
import henu.soft.xiaosi.pojo.Admin;
import henu.soft.xiaosi.pojo.User;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;




public class UserRealm extends AuthorizingRealm {


    @Autowired
    LoginMapper loginMapper;

    //授权
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();

        //拿到当前登录的对象
        Subject subject = SecurityUtils.getSubject();
        Admin currentAdmin = (Admin) subject.getPrincipal();
        //System.out.println("debug===>" + currentUser.getLimits());

        //拿出来user表中limits字段
        //info.addStringPermission(currentUser.getLimits());

        // 拿出来admin表的role字段
        info.addRole(currentAdmin.getRole());
        return info;
    }

    //认证
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
    //        String username = "scl";
    //        String password = "123456";


        //刚才的token是全局的，可以在这里取出认证
        UsernamePasswordToken token = (UsernamePasswordToken) authenticationToken;

        Admin admin = loginMapper.getAdminByUserNumber(token.getUsername());

        if(admin == null){
            //用户名认证，用户名不同会自动抛出用户不存在异常
            return null;
        }

        System.out.println("认证方法执行了debug===>" + admin.getRole());
        //密码认证Shiro自己做,如果还需要设置权限授予，需要将user参数传递给SimpleAuthenticationInfo
        return new SimpleAuthenticationInfo(admin,admin.getPassword(),"");

    }
}

