const menu = [

    // 新增
    // 首页
    {
        "name": "首页",
        "icon": "&#xe68e;",
        "url": "index.html",
        "hidden": true,
        "list": []
    },


    // 一 、信息第一部分
    // 1. 招生动态
    {
        "name": "招生动态",
        "icon": "&#xe630",
        "url": "",
        "target": "_blank",
        "hidden": false,
        "list": [{
            "name": "招生新闻",
            "url": "recruitment_dynamics_news.html"
        },
            {
                "name": "最新发布",
                "url": "recruitment_dynamics_release.html"
            },
        ]
    },
    // 2. 报考指南
    {
        "name": "报考指南",
        "icon": "&#xe62e",
        "url": "",
        "target": "_blank",
        "hidden": true,
        "list": [

            {
                "name": "招生简章",
                "url": "application_guide_brochure.html"
            },
            {
                "name": "往年参考",
                "url": "application_guide_reference.html"
            },

        ]
    },
    // 3. 魅力学府
    {
        "name": "魅力学府",
        "icon": "&#xe62e",
        "url": "",
        "target": "_blank",
        "hidden": true,
        "list": [
        	{
				"name": "学府概略",
				"url": "charm_academy_generalities.html"
        	},
            {
                "name": "学府影音",
                "url": "charm_academy_audio.html"
            },
            {
                "name": "学府故事",
                "url": "charm_academy_stories.html"
            },

        ]
    },
    // 4. 互动服务
    {
        "name": "互动服务",
        "icon": "&#xe62e",
        "url": "",
        "target": "_blank",
        "hidden": true,
        "list": [{
            "name": "常见问题",
            "url": "interactive_services_problems.html"
        },
            {
                "name": "留言",
                "url": "interactive_services_message.html"
            },
            {
                "name": "录取信息",
                "url": "enrol_info.html"
            },


        ]
    },
    // 5. 用户管理
    // 用户管理
    {
        "name": "用户管理",
        "icon": "&#xe612;",
        "url": "",
        "hidden": true,
        "list": [
        	{
				"name": "用户列表",
				"url": "user_index.html"
        	},
            {
                "name": "添加用户",
                "url": "user_add.html"
            },
        ]
    },


    // 信息第二部分

    // 招生信息

    {
        "name": "招生信息",
        "icon": "&#xe612;",
        "url": "",
        "hidden": true,
        "list": [
            {
                "name": "招生要闻",
                "url": "user_index.html"
            },
            {
                "name": "招办发布",
                "url": "user_add.html"
            },
            {
                "name": "学院动态",
                "url": "user_index.html"
            },
            {
                "name": "招生计划",
                "url": "user_add.html"
            },
            {
                "name": "招生简章",
                "url": "user_index.html"
            },
            {
                "name": "往年参考",
                "url": "user_add.html"
            },
        ]
    },


    // 退出登录
    {
        "name": "退出登录",
        "icon": "&#xe65c;",
        "url": "out.html",
        "list": []
    }


];

const config = {
    name: "Henu",
    menu: menu,
    version: 'v1.6',
    official: 'http://www.qadmin.net'
};

try {
    module.exports.name = "Qadmin";
    module.exports.menu = menu;
} catch (e) {

}
