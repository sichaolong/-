package henu.soft.xiaosi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnrollmentInformationSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
