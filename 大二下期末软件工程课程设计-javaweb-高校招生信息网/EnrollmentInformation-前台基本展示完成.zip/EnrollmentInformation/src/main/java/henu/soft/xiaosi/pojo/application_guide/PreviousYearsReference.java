package henu.soft.xiaosi.pojo.application_guide;

import lombok.*;

/**
 * 往年参考
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PreviousYearsReference {
    String id;
    String articleId;
    String articleTitle;
    String file;
}
