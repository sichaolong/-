package henu.soft.xiaosi.controller;

import com.alibaba.druid.support.json.JSONUtils;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import henu.soft.xiaosi.mapper.RecruitmentDynamicsMapper;
import henu.soft.xiaosi.pojo.recruitment_dynamics.AdmissionsNews;
import henu.soft.xiaosi.pojo.recruitment_dynamics.NewRelease;
import henu.soft.xiaosi.pojo.recruitment_dynamics.RecruitmentDynamics;
import org.apache.tomcat.util.json.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class RecruitmentDynamicsController {

    @Autowired
    RecruitmentDynamicsMapper recruitmentDynamicsMapper;


    @RequestMapping("/get-recruitment-dynamics")
    @ResponseBody
    public String getAll() throws JsonProcessingException {
        List<AdmissionsNews> admissionsNewsAll = recruitmentDynamicsMapper.findAdmissionsNewsAll();
        List<NewRelease> newReleaseAll = recruitmentDynamicsMapper.findNewReleaseAll();

        RecruitmentDynamics recruitmentDynamics = new RecruitmentDynamics(admissionsNewsAll,newReleaseAll);
//        mv.addObject("admissionsNewsAll",admissionsNewsAll);
//        mv.addObject("newReleaseAll",newReleaseAll);
//        mv.setViewName("index");

//        model.addAttribute("admissionsNewsAll",admissionsNewsAll);
//        model.addAttribute("newReleaseAll",newReleaseAll);
        ObjectMapper mapper = new ObjectMapper();
        String str = mapper.writeValueAsString(recruitmentDynamics);

        return str;



    }



}
