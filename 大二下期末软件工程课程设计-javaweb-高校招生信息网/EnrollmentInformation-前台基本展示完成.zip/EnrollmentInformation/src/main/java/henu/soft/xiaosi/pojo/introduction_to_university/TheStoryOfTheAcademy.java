package henu.soft.xiaosi.pojo.introduction_to_university;

import lombok.*;

/**
 * 学府故事
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TheStoryOfTheAcademy {
    String id;

    String articleId;
    String articleTitle;
    String content;
}
