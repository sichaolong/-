package henu.soft.xiaosi.pojo.introduction_to_university;


import lombok.*;

import java.util.List;

/**
 * 学府介绍
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class IntroductionToUniversity {
    //学府影印
    List<UniversityOfAudioVisual> universityOfAudioVisuals;
    //学府概述
    List<AnOverviewOfTheUniversity> anOverviewOfTheUniversities;
    // 学府故事
    List<TheStoryOfTheAcademy> theStoryOfTheAcademies;

}
