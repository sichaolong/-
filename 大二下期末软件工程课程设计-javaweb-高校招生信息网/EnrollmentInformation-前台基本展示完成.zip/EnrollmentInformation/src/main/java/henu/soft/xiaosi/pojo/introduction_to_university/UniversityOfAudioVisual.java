package henu.soft.xiaosi.pojo.introduction_to_university;

import lombok.*;

/**
 * 学府影音
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UniversityOfAudioVisual {
    String id;
    String articleId;
    String articleTitle;
    String content;
}
