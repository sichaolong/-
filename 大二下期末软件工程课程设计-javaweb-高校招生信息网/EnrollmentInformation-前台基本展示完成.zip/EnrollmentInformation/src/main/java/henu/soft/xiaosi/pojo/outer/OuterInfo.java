package henu.soft.xiaosi.pojo.outer;

import lombok.*;

import java.util.List;

@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class OuterInfo {
    List<OuterNew> outerNews;
    List<OuterRelease> outerReleases;
}
