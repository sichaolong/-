package henu.soft.xiaosi.pojo.interactive_services;

import lombok.*;

import java.util.List;

/**
 * 互动服务
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class InteractiveServices {
    // 常见问题
    List<FrequentlyAskedQuestions> frequentlyAskedQuestions;

    // 留言
    List<MessageManagement> messageManagements;
}
