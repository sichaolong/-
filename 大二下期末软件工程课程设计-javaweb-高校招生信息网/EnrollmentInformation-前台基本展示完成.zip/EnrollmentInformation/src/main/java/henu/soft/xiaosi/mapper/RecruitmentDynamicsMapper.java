package henu.soft.xiaosi.mapper;

import henu.soft.xiaosi.pojo.recruitment_dynamics.AdmissionsNews;
import henu.soft.xiaosi.pojo.recruitment_dynamics.NewRelease;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface RecruitmentDynamicsMapper {
    // 查询所有的信息
    List<AdmissionsNews> findAdmissionsNewsAll();

    List<NewRelease> findNewReleaseAll();

    // 查

    AdmissionsNews findAdmissionsNewsById(int id);

    NewRelease findNewReleaseById(int id);

    // 增
    void saveAdmissionsNews(AdmissionsNews admissionsNews);
    void saveNewRelease(NewRelease newRelease);

    // 删

    void deleteAdmissionsNews(int id);
    void deleteNewReleases(int id);

    // 改

    AdmissionsNews updateAdmissionsNewsById(AdmissionsNews admissionsNews);
    NewRelease updateNewReleaseById(NewRelease newRelease);








}
