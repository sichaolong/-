package henu.soft.xiaosi.mapper;

import henu.soft.xiaosi.pojo.outer.OuterNew;
import henu.soft.xiaosi.pojo.outer.OuterRelease;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface OuterInfoMapper {

    List<OuterNew> findOuterNews();
    List<OuterRelease> findOuterReleases();
}
