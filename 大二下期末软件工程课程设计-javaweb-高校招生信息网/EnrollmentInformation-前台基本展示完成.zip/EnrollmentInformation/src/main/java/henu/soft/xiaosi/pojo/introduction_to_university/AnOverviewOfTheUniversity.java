package henu.soft.xiaosi.pojo.introduction_to_university;


import lombok.*;

/**
 * 学府概述
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class AnOverviewOfTheUniversity {
    String id;

    String articleId;
    String articleTitle;
    String content;
}
