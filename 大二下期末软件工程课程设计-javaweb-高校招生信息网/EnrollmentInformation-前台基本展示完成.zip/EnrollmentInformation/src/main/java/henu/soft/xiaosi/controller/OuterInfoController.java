package henu.soft.xiaosi.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import henu.soft.xiaosi.mapper.OuterInfoMapper;

import henu.soft.xiaosi.pojo.outer.OuterInfo;
import henu.soft.xiaosi.pojo.outer.OuterNew;
import henu.soft.xiaosi.pojo.outer.OuterRelease;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class OuterInfoController {

    @Autowired
    OuterInfoMapper outerInfoMapper;

    @RequestMapping("/get-outer-info")
    @ResponseBody
    public String getAll() throws JsonProcessingException {

        List<OuterNew> outerNews = outerInfoMapper.findOuterNews();
        List<OuterRelease> outerReleases = outerInfoMapper.findOuterReleases();

        OuterInfo outerInfo = new OuterInfo(outerNews,outerReleases);

        ObjectMapper mapper = new ObjectMapper();
        String str = mapper.writeValueAsString(outerInfo);

        return str;



    }
}
