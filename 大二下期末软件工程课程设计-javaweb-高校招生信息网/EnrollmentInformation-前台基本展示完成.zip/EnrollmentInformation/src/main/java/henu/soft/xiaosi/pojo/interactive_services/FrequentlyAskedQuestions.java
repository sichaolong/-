package henu.soft.xiaosi.pojo.interactive_services;

import lombok.*;

/**
 * 常见问题
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class FrequentlyAskedQuestions {
    String id;
    String articleId;
    String author;
    String articleTitle;
    String content;
    String date;

}
