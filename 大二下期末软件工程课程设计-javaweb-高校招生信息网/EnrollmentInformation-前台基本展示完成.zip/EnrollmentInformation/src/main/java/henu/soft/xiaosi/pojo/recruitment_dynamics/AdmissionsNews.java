package henu.soft.xiaosi.pojo.recruitment_dynamics;

import lombok.*;

/**
 * 招生新闻
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class AdmissionsNews {
    String id;
    String articleId;
    String articleTitle;
    String content;
    String date;
}
