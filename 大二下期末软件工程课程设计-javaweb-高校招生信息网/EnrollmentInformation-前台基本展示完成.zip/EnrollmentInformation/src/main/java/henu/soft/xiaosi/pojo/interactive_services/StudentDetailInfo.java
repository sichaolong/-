package henu.soft.xiaosi.pojo.interactive_services;

import lombok.*;

/**
 * 留言学生信息
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class StudentDetailInfo {


    String s_id;
    // 学生地区
    String studentLocation;
    // 学生毕业高中
    String highSchool;
    // 留言时间
    String questTime;
}
