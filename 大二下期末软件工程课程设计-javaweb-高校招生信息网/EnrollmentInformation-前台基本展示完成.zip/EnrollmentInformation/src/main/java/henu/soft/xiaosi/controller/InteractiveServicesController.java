package henu.soft.xiaosi.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import henu.soft.xiaosi.mapper.InteractiveServicesMapper;
import henu.soft.xiaosi.pojo.interactive_services.FrequentlyAskedQuestions;
import henu.soft.xiaosi.pojo.interactive_services.InteractiveServices;
import henu.soft.xiaosi.pojo.interactive_services.MessageManagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class InteractiveServicesController {

    @Autowired
    InteractiveServicesMapper interactiveServicesMapper;


    @RequestMapping("/get-interactive-services")
    @ResponseBody
    public String getAll() throws JsonProcessingException {
        List<FrequentlyAskedQuestions> frequentlyAskedQuestions = interactiveServicesMapper.findFrequentlyAskedQuestions();
        List<MessageManagement> messageManagements = interactiveServicesMapper.findMessageManagements();

        InteractiveServices interactiveServices = new InteractiveServices(frequentlyAskedQuestions,messageManagements);

        ObjectMapper mapper = new ObjectMapper();
        String str = mapper.writeValueAsString(interactiveServices);

        return str;



    }


}
