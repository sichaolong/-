package henu.soft.xiaosi.pojo.application_guide;

import lombok.*;

/**
 * 招生计划
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EnrollmentPlan {
    String id;
    String articleId;
    String articleTitle;
    String file;
}
