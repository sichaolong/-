package henu.soft.xiaosi.mapper;

import henu.soft.xiaosi.pojo.user.Admin;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface LoginMapper {


    // 查询所有
    List<Admin> getAllAdmin();

    // 新增
    Boolean saveOneAdmin(Admin admin);

    // 根据userNumber查询
    Admin getAdminByUserNumber(String userNumber);


    // 根据userNumber删除
    Boolean deleteAdminByUserNumber(String userNumber);

    // 根据userNumber更新

    Boolean updateAdminByUserNumber(Admin admin);


}
