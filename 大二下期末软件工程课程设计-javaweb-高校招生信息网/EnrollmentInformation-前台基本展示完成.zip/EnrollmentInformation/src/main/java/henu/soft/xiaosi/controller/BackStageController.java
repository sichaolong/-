package henu.soft.xiaosi.controller;


import org.apache.shiro.authz.annotation.RequiresAuthentication;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BackStageController {


    //    0.跳转后台

    @RequestMapping("back/index.html")
    public String index() {

        return "back/index";
    }


    /**
     * 第一部分
     * @return
     */

    //    1.首页
    @RequestMapping("back/main.html")
    public String main() {

        return "back/main";
    }

    //    2.招生要闻
    @RequestMapping("back/recruitment_dynamics_news.html")
    public String news() {

        return "back/recruitment_dynamics_news";
    }

    //    2.最新发布
    @RequestMapping("back/recruitment_dynamics_release.html")
    public String release() {

        return "back/recruitment_dynamics_release";
    }

    //    3.招生计划
    @RequestMapping("back/application_guide_plan.html")
    public String plan() {

        return "back/application_guide_plan";
    }

    //    3.招生简章
    @RequestMapping("back/application_guide_brochure.html")
    public String brochure() {

        return "back/application_guide_brochure";
    }

    //    3. 往年参考
    @RequestMapping("back/application_guide_reference.html")
    public String reference() {

        return "back/application_guide_reference";
    }

    //    4.学府概略
    @RequestMapping("back/charm_academy_generalities.html")
    public String generalities() {

        return "back/charm_academy_generalities";
    }

    //    4.学府影音
    @RequestMapping("back/charm_academy_audio.html")
    public String audio() {

        return "back/charm_academy_audio";
    }

    //    4. 学府故事
    @RequestMapping("back/charm_academy_stories.html")
    public String stories() {

        return "back/charm_academy_stories";
    }

    //    5.常见问题
    @RequestMapping("back/interactive_services_problems.html")
    public String problems() {

        return "back/interactive_services_problems";
    }

    //    5. 留言
    @RequestMapping("back/interactive_services_message.html")
    public String message() {

        return "back/interactive_services_message";
    }

    // 6. 用户列表
    @RequestMapping("back/user_index.html")
    public String user_list() {

        return "back/user_index";
    }

    // 6. 增加用户

    @RequestMapping("back/user_add.html")
    public String user_add() {

        return "back/user_add";
    }

    // 7. 密码修改

    @RequestMapping("back/web_pwd.html")
    public String password() {

        return "back/web_pwd";
    }







    /**
     * 第二部分
     */

    /*

    //    1.招生要闻
    @RequestMapping("back/recruitment_dynamics_release.html")
    public String release() {

        return "back/recruitment_dynamics_release";
    }

    //    1. 招办发布
    @RequestMapping("back/recruitment_dynamics_news.html")
    public String news() {

        return "back/recruitment_dynamics_news";
    }
    //    1.学院动态
    @RequestMapping("back/recruitment_dynamics_release.html")
    public String release() {

        return "back/recruitment_dynamics_release";
    }

    //    2. 招生计划
    @RequestMapping("back/recruitment_dynamics_news.html")
    public String news() {

        return "back/recruitment_dynamics_news";
    }
    //    2. 招生简章
    @RequestMapping("back/recruitment_dynamics_release.html")
    public String release() {

        return "back/recruitment_dynamics_release";
    }

    //    2. 往年参考
    @RequestMapping("back/recruitment_dynamics_news.html")
    public String news() {

        return "back/recruitment_dynamics_news";
    }


     */





}
