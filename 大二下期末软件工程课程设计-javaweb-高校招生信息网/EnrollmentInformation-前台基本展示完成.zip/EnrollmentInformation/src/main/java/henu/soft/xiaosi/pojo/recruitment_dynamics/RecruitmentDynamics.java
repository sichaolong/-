package henu.soft.xiaosi.pojo.recruitment_dynamics;


import lombok.*;

import java.io.Serializable;
import java.util.List;

/**
 * 招生动态
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class RecruitmentDynamics implements Serializable {
    //招生新闻
    List<AdmissionsNews> admissionsNews;
    //最新发布
    List<NewRelease> newReleases;
}
