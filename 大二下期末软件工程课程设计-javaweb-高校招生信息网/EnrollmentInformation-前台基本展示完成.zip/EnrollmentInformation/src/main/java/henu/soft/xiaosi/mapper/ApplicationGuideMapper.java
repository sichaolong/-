package henu.soft.xiaosi.mapper;

import henu.soft.xiaosi.pojo.application_guide.AdmissionsBrochure;
import henu.soft.xiaosi.pojo.application_guide.EnrollmentPlan;
import henu.soft.xiaosi.pojo.application_guide.PreviousYearsReference;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface ApplicationGuideMapper {

    // 1. 查

    // 招生简章
    List<AdmissionsBrochure> findAdmissionsBrochures();

    // 招生计划
    List<EnrollmentPlan> findEnrollmentPlans();

    // 往年参考
    List<PreviousYearsReference> findPreviousYearsReferences();
}
