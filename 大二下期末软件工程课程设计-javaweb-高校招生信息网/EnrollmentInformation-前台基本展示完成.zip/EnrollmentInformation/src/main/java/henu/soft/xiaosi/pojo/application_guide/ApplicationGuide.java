package henu.soft.xiaosi.pojo.application_guide;


import lombok.*;

import java.util.List;

/**
 * 报考指南
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ApplicationGuide {

    // 招生简章
    List<AdmissionsBrochure> admissionsBrochures;

    // 招生计划
    List<EnrollmentPlan> enrollmentPlans;

    // 往年参考
    List<PreviousYearsReference> previousYearsReferences;
}
