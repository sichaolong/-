package henu.soft.xiaosi.pojo.outer;

import lombok.*;

@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class OuterRelease {

    String id;
    String articleId;
    String articleTitle;
    String content;
    String date;
}
