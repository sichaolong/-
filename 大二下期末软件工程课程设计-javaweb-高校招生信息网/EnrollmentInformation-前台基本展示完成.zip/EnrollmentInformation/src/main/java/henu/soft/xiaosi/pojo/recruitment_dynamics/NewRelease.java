package henu.soft.xiaosi.pojo.recruitment_dynamics;

import lombok.*;

/**
 * 最新发布
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class NewRelease {
    String id;
    String articleId;
    String articleTitle;
    String content;
    String date;
}
