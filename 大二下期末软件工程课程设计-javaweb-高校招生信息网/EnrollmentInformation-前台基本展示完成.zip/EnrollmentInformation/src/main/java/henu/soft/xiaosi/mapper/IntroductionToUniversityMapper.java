package henu.soft.xiaosi.mapper;


import henu.soft.xiaosi.pojo.introduction_to_university.AnOverviewOfTheUniversity;
import henu.soft.xiaosi.pojo.introduction_to_university.TheStoryOfTheAcademy;
import henu.soft.xiaosi.pojo.introduction_to_university.UniversityOfAudioVisual;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface IntroductionToUniversityMapper {

    // 1. 查

    //学府影印
    List<UniversityOfAudioVisual> findUniversityOfAudioVisuals();
    //学府概述
    List<AnOverviewOfTheUniversity> findAnOverviewOfTheUniversities();
    // 学府故事
    List<TheStoryOfTheAcademy> findTheStoryOfTheAcademies();
}
