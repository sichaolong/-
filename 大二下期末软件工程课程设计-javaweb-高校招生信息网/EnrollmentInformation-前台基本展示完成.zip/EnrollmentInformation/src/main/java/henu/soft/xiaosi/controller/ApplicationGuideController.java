package henu.soft.xiaosi.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import henu.soft.xiaosi.mapper.ApplicationGuideMapper;
import henu.soft.xiaosi.pojo.application_guide.AdmissionsBrochure;
import henu.soft.xiaosi.pojo.application_guide.ApplicationGuide;
import henu.soft.xiaosi.pojo.application_guide.EnrollmentPlan;
import henu.soft.xiaosi.pojo.application_guide.PreviousYearsReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class ApplicationGuideController {

    @Autowired
    ApplicationGuideMapper applicationGuideMapper;

    @RequestMapping("/get-application-guide")
    @ResponseBody
    public String getAll() throws JsonProcessingException {
        List<AdmissionsBrochure> admissionsBrochures = applicationGuideMapper.findAdmissionsBrochures();
        List<EnrollmentPlan> enrollmentPlans = applicationGuideMapper.findEnrollmentPlans();
        List<PreviousYearsReference> previousYearsReferences = applicationGuideMapper.findPreviousYearsReferences();


        ApplicationGuide applicationGuide = new ApplicationGuide(admissionsBrochures,enrollmentPlans,previousYearsReferences);

        ObjectMapper mapper = new ObjectMapper();
        String str = mapper.writeValueAsString(applicationGuide);

        return str;



    }



}
