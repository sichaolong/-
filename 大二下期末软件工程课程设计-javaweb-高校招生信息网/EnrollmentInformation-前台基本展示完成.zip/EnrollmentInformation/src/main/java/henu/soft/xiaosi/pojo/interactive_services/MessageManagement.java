package henu.soft.xiaosi.pojo.interactive_services;


import lombok.*;

/**
 * 留言
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MessageManagement {
    String id;
    String msgId;
    String problem;
    String answer;
    // 留言学生详细信息
    StudentDetailInfo studentDetailInfo;
}
