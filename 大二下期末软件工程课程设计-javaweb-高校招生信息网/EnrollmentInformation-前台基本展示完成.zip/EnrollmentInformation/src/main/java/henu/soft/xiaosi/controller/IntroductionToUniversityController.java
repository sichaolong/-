package henu.soft.xiaosi.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import henu.soft.xiaosi.mapper.IntroductionToUniversityMapper;
import henu.soft.xiaosi.pojo.application_guide.AdmissionsBrochure;
import henu.soft.xiaosi.pojo.application_guide.ApplicationGuide;
import henu.soft.xiaosi.pojo.application_guide.EnrollmentPlan;
import henu.soft.xiaosi.pojo.application_guide.PreviousYearsReference;
import henu.soft.xiaosi.pojo.introduction_to_university.AnOverviewOfTheUniversity;
import henu.soft.xiaosi.pojo.introduction_to_university.IntroductionToUniversity;
import henu.soft.xiaosi.pojo.introduction_to_university.TheStoryOfTheAcademy;
import henu.soft.xiaosi.pojo.introduction_to_university.UniversityOfAudioVisual;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class IntroductionToUniversityController {

    @Autowired
    IntroductionToUniversityMapper introductionToUniversityMapper;

    @RequestMapping("/get-introduction-to-university")
    @ResponseBody
    public String getAll() throws JsonProcessingException {
        List<AnOverviewOfTheUniversity> anOverviewOfTheUniversities = introductionToUniversityMapper.findAnOverviewOfTheUniversities();
        List<TheStoryOfTheAcademy> theStoryOfTheAcademies = introductionToUniversityMapper.findTheStoryOfTheAcademies();
        List<UniversityOfAudioVisual> universityOfAudioVisuals = introductionToUniversityMapper.findUniversityOfAudioVisuals();

        IntroductionToUniversity introductionToUniversity = new IntroductionToUniversity(universityOfAudioVisuals,anOverviewOfTheUniversities,theStoryOfTheAcademies);

        ObjectMapper mapper = new ObjectMapper();
        String str = mapper.writeValueAsString(introductionToUniversity);

        return str;



    }

}
