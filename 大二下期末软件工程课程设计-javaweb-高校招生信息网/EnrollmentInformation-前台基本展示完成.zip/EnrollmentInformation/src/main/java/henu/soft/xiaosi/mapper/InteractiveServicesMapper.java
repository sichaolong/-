package henu.soft.xiaosi.mapper;


import henu.soft.xiaosi.pojo.interactive_services.FrequentlyAskedQuestions;
import henu.soft.xiaosi.pojo.interactive_services.MessageManagement;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface InteractiveServicesMapper {

    // 常见问题
    List<FrequentlyAskedQuestions> findFrequentlyAskedQuestions();

    // 留言
    List<MessageManagement> findMessageManagements();
}
