package henu.soft.xiaosi;

import henu.soft.xiaosi.mapper.RecruitmentDynamicsMapper;
import henu.soft.xiaosi.pojo.recruitment_dynamics.AdmissionsNews;
import henu.soft.xiaosi.pojo.recruitment_dynamics.NewRelease;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@SpringBootTest
class EnrollmentInformationSystemApplicationTests {

    @Test
    void contextLoads() {
    }

    @Autowired
    RecruitmentDynamicsMapper recruitmentDynamicsMapper;


   @Test
    public void getAllAdmissionsNews(){
        List<AdmissionsNews> admissionsNewsAll = recruitmentDynamicsMapper.findAdmissionsNewsAll();
        System.out.println(admissionsNewsAll);
    }

    @Test
    public void getAllNewRelease(){
        List<NewRelease> newReleaseAll = recruitmentDynamicsMapper.findNewReleaseAll();
        System.out.println(newReleaseAll);
    }

    @Test
    public void saveAdmissionsNews(){
        AdmissionsNews admissionsNews = new AdmissionsNews();
        admissionsNews.setArticleTitle("测试招生信息标题");
        admissionsNews.setContent("测试招生信息文章内容！");
        admissionsNews.setDate("2099-99-99");
        recruitmentDynamicsMapper.saveAdmissionsNews(admissionsNews);

    }

    @Test
    public void saveNewRelease(){
       NewRelease newRelease = new NewRelease();
       newRelease.setArticleTitle("测试最新发布标题！");
       newRelease.setContent("测试最新发布文章内容！");
       newRelease.setDate("2088-88-88");
       recruitmentDynamicsMapper.saveNewRelease(newRelease);

    }

}
